Statistics Logger​ for TIBCO Enterprise Message Service(TM)
=========================================================

Introduction

This tool can be used to log and monitor EMS (including EMS Appliance) server statistics. Server Statistics can be logged to local CSV files and can additionally be pushed to either AWS CloudWatch or to the Prometheus monitoring tool.

The package contains the following Java classes:

- EmsStatsLogger: Regularly polls and logs EMS server statistics to CSV files, which can easily be graphed in tools such as Excel. A new CSV file is generated for each day.

- EmsStatsCloudWatchPusher: This class pushes EMS server statistics to AWS CloudWatch. Statistics can also be optionally logged to a local CSV file.

- EmsStatsPromCollector: This class collects EMS server statistics for export to Prometheus. Statistics can also be optionally logged to a local CSV file. 
			 Prometheus is a powerful open source monitoring system see https://prometheus.io

The following EMS server metrics can be monitored:

	- Inbound/outbound message/byte rates
	- Pending message count/size
	- Connection/session counts
	- Destination counts
	- Message memory usage
	- Disk read/write rates
	- Sync/async datastore sizes
	- Response time

The following EMS queue/topic metrics can be monitored:

	- Inbound/outbound message/byte rates
	- Inbound/outbound total message/byte counts
	- Pending message count/size
	- Receiver/Consumer counts

The EMS server metrics are documented EMS Admin API ServerInfo class, for further details see:

	https://docs.tibco.com/pub/ems/8.4.0/doc/html/tib_ems_api_ref/api/javadoc/com/tibco/tibjms/admin/ServerInfo.html

The EMS queue/topic metrics are documented EMS Admin API DestnationInfo, QueueInfo, TopicInfo and StatData classes, for further details see:

	https://docs.tibco.com/pub/ems/8.4.0/doc/html/tib_ems_api_ref/api/javadoc/com/tibco/tibjms/admin/DestinationInfo.html
	https://docs.tibco.com/pub/ems/8.4.0/doc/html/tib_ems_api_ref/api/javadoc/com/tibco/tibjms/admin/QueueInfo.html
	https://docs.tibco.com/pub/ems/8.4.0/doc/html/tib_ems_api_ref/api/javadoc/com/tibco/tibjms/admin/TopicInfo.html
	https://docs.tibco.com/pub/ems/8.4.0/doc/html/tib_ems_api_ref/api/javadoc/com/tibco/tibjms/admin/StatData.html


The package also contains the following sample Grafana dashboards for visualising the statistics stored in Prometheus (for further details on Grafana see https://grafana.com)

	- EMS Overview (graphs in/outbound message rates, pending message size/count, connection count and response time)
	- EMS Details (graphs memory usage, sync/async datastore size and disk read/write rates)
	- EMS Queues (graphs queue in/outbound message rates, pending message size/count, receiver counts)
	- EMS Topics (graphs queue in/outbound message rates, pending message size/count, consumer counts)


Author: Richard Lawrence (rlawrenc@tibco.com)

  
======================================================================
Version History

Version 3.0

	- Added support for monitoring multiple EMS servers
	- Added support for SSL connections
	- Added support for configuration with servers.xml file
	- Added support for monitoring queues and topics
	- Added support to auto cleanup old log files
	- Changed emsStatsPromPusher to emsStatsPromCollector (Prometheus now directly scrapes the collector for stats)
	- Updated Grafana dashboards, including new dashboards for Queues and Topics

Version 2.1

	- Added logfile option to override log file name
	- Added noappend option to prevent append to log file on restart


Version 2.0

	- Added emsStatsCloudWatchPusher

======================================================================
Software Requirements

	- JRE 1.8 or higher
	- TIBCO Enterprise Message Service 8.1 or higher (client).
	- For EmsStatsCloudWatchPusher:
		AWS SDK for Java

To build the source, the following libs are also required:
	- For EmsStatsPromCollector: Prometheus simpleclient, simpleclient_common and simpleclient_httpserver available at:

		https://github.com/prometheus/client_java
      
======================================================================
Installation

Follow this procedure to install this tool into your environment:

- Unpack the emsStatsLogger.zip file.

- Edit the servers.xml file to add connection detail for the EMS servers to be monitored.

- Edit the run scripts to make appropriate versions for your environment:
	
	- Set the TIBEMS_ROOT variable to your TIBCO EMS installation directory (EMS client 8.1 or greater required)
	- Set the appropriate command line options for your environment

======================================================================
Installation for Prometheus


- Download Prometheus and the PushGateway from:

	https://prometheus.io/download/

- Edit the prometheus.yml file and configure a scrape config for the collector targets. There are three collector targets, one for EMS server stats, one for queue stats and one for topic stats.
  Configure the collector targets appropriately for where the EmsStatsPromCollector is running, the example below show default configuration if the collector is running on the same host as the Prometheus server.
  Remove the queue/topic collector target if not required.

scrape_configs:
  - job_name:       'TIB-EMS'
    scrape_interval: 60s
    scrape_timeout: 10s
    honor_labels: true
    static_configs:
      - targets: ['127.0.0.1:9091', '127.0.0.1:9092', '127.0.0.1:9093']

You may add multiple scrape configs for different EmsStatsPromCollector instances, for example for different EMS environments.
Ensure the job names are different and match those configured using the command line when ruuning the collector.

By default EmsStatsPromCollector listens on HTTP port 9091 for exporting EMS server stats, 9092 for queue stats, and 9092 for topic stats.
The Prometheus server listens on TCP port 9090 by default.

Note; you no longer need to run the Prometheus gateway, the prometheus server now scrapes the EmsStatsPromCollector directly.
  
Edit the runPromCollector.sh file and configure appropriate HTTP ports if necessary for your environment.
	Use the -nolog command line option to prevent logging to local file if required.

To Install Grafana:

- Follow the instructions here:

	http://docs.grafana.org/installation/

By default grafana listens on TCP port 3000, default user/password is admin/admin

Open the grafana URL in a browser and create a prometheus data source called Prometheus, then simply import the sample dashboards provided or create your own.


======================================================================
Installation for pushing metrics to AWS CloudWatch

If running on EC2:
	Install AWS SDK using the command:
		wget http://sdk-for-java.amazonwebservices.com/latest/aws-java-sdk.zip

	Create an IAM role and then give your EC2 instance access to that role as shown in:
		https://docs.aws.amazon.com/sdk-for-java/v1/developer-guide/java-dg-roles.html

The AWS SDK library can also be downloaded here:
	https://github.com/aws/aws-sdk-java

Edit the runCloudWatchPusher.sh file and set the appropriate configuration for your environment.
	Use the -accessId -secretKey and -region options if you are not running the tool on AWS or want to send the stats to a different region
	Use the -nolog command line option to prevent logging to local file if required.


======================================================================
EmsStatsLogger

The EmsStatsLogger class logs EMS server statistics to an output CSV file once every poll interval. By default a new output log file is created for each day, this may be overridden using the logfile parameter.


Usage: java EmsStatsLogger [options]

   where options are:

  -config    <config file>       - Server config filename, default servers.xml
  -interval  <secs>              - interval between log entries, default 30 seconds
  -debug                         - Enable debug trace to stdout



======================================================================
EmsStatsPromCollector

The EmsStatsPromCollector class inherits from EmsStatsLogger and in addition to logging EMS statistics to file also collects the statistics for monitoring with Prometheus. Logging to file can be disabled if not required.
You may set a job name to represent the EMS environment being monitored, eg: PROD, QA, DEV etc.
Ensure you add a prometheus scrape target for each environment/job and the job names match those configured in the prometheus.yml file.

Usage: java EmsStatsPromCollector [options]

   where options are:

  -config    <config file>       - Server config filename, default servers.xml 
  -interval  <secs>              - interval between log entries, default 30 seconds
  -serverStatsPort  <port>       - The HTTP port to scrape for EMS server stats, default 9091. (0 disables)
  -queueStatsPort   <port>       - The HTTP port to scrape for EMS queue stats, default 9092. (0 disables)
  -topicStatsPort   <port>       - The HTTP port to scrape for EMS topic stats, default 9093. (0 disables)
  -job              <job-name>   - The Prometheus job-name, default TIB-EMS
  -nolog                         - Prevent all logging of stats to log directories, default false

======================================================================
EmsStatsCloudWatchPusher

The EmsStatsCloudWatchPusher class inherits from EmsStatsLogger and in addition to logging EMS statistics to file also sends the statistics to AWS CloudWatch. If you are not running the tool on AWS you must supply the accessId, secretKey and region parameters for your AWS environment. Logging to file can be disabled if not required.

Usage: java EmsStatsCloudWatchPusher [options]

   where options are:

  -config    <config file>       - Server config filename, default servers.xml 
  -interval  <secs>              - interval between log entries, default 30 seconds
  -accessId  <accessId>          - AWS access Id (default environment credentials)
  -secretKey <secretKey>         - AWS secret key (default environment credentials)
  -region    <region>            - AWS region (default current region)
  -ns        <namespace>         - AWS namespace (default TIBCO/EMS)
  -nolog                         - Prevent all logging of stats to log directories, default false





