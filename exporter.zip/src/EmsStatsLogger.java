/* Copyright (c) 2017-2018 TIBCO Software Inc.
 * All rights reserved.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 * 
 * TIBCO EMS Server Statistics Logger
 *
 * Uses EMS Admin API to collect server info stats and log them to CSV file.
 *
 * Compile with EMS client API V8.1 or greater; tibjmsadmin.jar
 *
 * @author rlawrence
 *
 */

import java.util.Date;
import java.io.*;
import java.util.zip.GZIPOutputStream;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Map;
import java.util.Vector;
import java.text.SimpleDateFormat;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import com.tibco.tibjms.admin.*;


public class EmsStatsLogger 
{

    // Method properties from the EMS Admin API ServerInfo, DestinationInfo, QueueInfo, TopicInfo, StatData classes that match the following statistics naming patterns are automatically logged:
    // *MsgMem* *Rate *Size *Count *TotalMessages *TotalBytes
    //
    // However those properties that match the following names are excluded:
    // *Log* *Max* *SSL* *Trace* *MessagePool*
    //
    // In addition the methods listed below are also excluded.
    // Add any additional get methods here that you dont wish to be logged.

    protected String[] m_methodExclusionList = {
	"getRouteRecoverCount",
	"getLargeDestCount"
    };

    class EmsLogEntry {
    	public EmsLogEntry() {};
	String  m_logFilename=null;
	String  m_logDir=null;
	int  m_logCleanup=m_defaultLogClean;
	boolean m_logAppend = true;
	boolean m_logZip = true;
	File m_logFile = null;
	FileOutputStream m_fileOut = null;
	PrintStream m_filePrint = null;
    }
    class EmsDestination extends EmsLogEntry {
    	public EmsDestination(String pattern, int permType, String logDir, String logFilename, int logCleanup, boolean logAppend, boolean logZip)
		{m_pattern=pattern;m_destPermType=permType;m_logDir=logDir;m_logFilename=logFilename;m_logCleanup=logCleanup;m_logAppend=logAppend;m_logZip=logZip;}
	String  m_pattern;
	int  	m_destPermType = m_defaultDestPermType;
	DestinationInfo[] m_info = null;
    }
    class EmsServer extends EmsLogEntry {
    	public EmsServer(String alias, String url, String user, String password, String logDir, String logFilename, int logCleanup, boolean logAppend, boolean logZip, Map sslParams, Hashtable<String, EmsDestination> queues, Hashtable<String, EmsDestination> topics)
		{m_alias=alias;m_serverUrl=url;m_user=user;m_password=password;m_logDir=logDir;m_logFilename=logFilename;m_logCleanup=logCleanup;m_logAppend=logAppend;m_logZip=logZip;m_sslParams=sslParams;m_queues=queues;m_topics=topics;}
	public void close() {
	    if (m_adminConn != null) {
		try { m_adminConn.close(); } catch (TibjmsAdminException e1) {}
	    }
	    m_adminConn = null;
	}
	String  m_alias;
	String  m_serverUrl;
	String  m_user;
	String  m_password;
	Map  	m_sslParams;
	Hashtable<String, EmsDestination> m_queues=null;
	Hashtable<String, EmsDestination> m_topics=null;
	TibjmsAdmin m_adminConn = null;
	TibjmsAdmin m_staleConn = null;
	ServerInfo m_serverInfo = null;
    }

    protected final String m_defaultURL = "tcp://localhost:7222";
    protected final String m_defaultUser = "admin";
    protected final String m_defaultPasswd = null;
    protected final String m_defaultLogDir = "./log";
    protected final String m_defaultLogFilename = "$N-$D.csv";
    protected final int m_defaultDestPermType= DestinationInfo.DEST_GET_STATIC;
    protected final int m_defaultLogClean = 60;
    protected final int m_minInterval = 20;
    protected final String m_csvDelim= ",";
    protected final int m_destCursorSize= 100;
    protected final int m_maxDestinations= 500;

    protected String  m_configFile = "servers.xml";
    protected int     m_interval = 30;
    protected boolean m_debug = false;

    protected Hashtable<String, EmsServer> m_servers = new Hashtable<String, EmsServer>();
    protected Vector<String> m_serverStatsNames=new Vector<String>();
    protected Vector<String> m_queueStatsNames=new Vector<String>();
    protected Vector<String> m_topicStatsNames=new Vector<String>();
    protected SimpleDateFormat m_fileDateFormat= new SimpleDateFormat("ddMMMyyyy");
    protected SimpleDateFormat m_timestampFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss SSS zzz yyyy");
    protected ConnectThread m_connectThread = null;
    protected Vector<EmsLogEntry> m_cleanupLogs=new Vector<EmsLogEntry>();

    public EmsStatsLogger() {
    }

    public EmsStatsLogger(String[] args) {

        parseArgs(args);
	init();
    	run();
    }

    public void init() {

	loadServersFromFile(m_configFile);

	getStatsMethodNames(m_serverStatsNames, ServerInfo.class, null);
	getStatsMethodNames(m_queueStatsNames, QueueInfo.class, null);
	getStatsMethodNames(m_queueStatsNames, StatData.class, "inbound");
	getStatsMethodNames(m_queueStatsNames, StatData.class, "outbound");
	getStatsMethodNames(m_topicStatsNames, TopicInfo.class, null);
	getStatsMethodNames(m_topicStatsNames, StatData.class, "inbound");
	getStatsMethodNames(m_topicStatsNames, StatData.class, "outbound");

	m_connectThread = new ConnectThread(m_interval);
    }

    public void addConnection(String serverName, String serverUrl, String user, String password, String logDir, String logFile, int logCleanup, boolean logAppend, boolean logZip, Map sslParams, Hashtable<String, EmsDestination> queues, Hashtable<String, EmsDestination> topics)
    {
	if (!m_servers.containsKey(serverName))
	{
	    if (serverUrl.startsWith("ssl") && (sslParams == null || sslParams.size() == 0))
		warn("ssl URL specfied but no SSL Parameters found for Server with alias "+serverName);
	    else
	    if (!serverUrl.startsWith("ssl") && (sslParams != null && sslParams.size() > 0))
		warn("SSL Parameters found but ssl URL not specfied for Server with alias "+serverName);

	    m_servers.put(serverName, new EmsServer(serverName, serverUrl, user, password, logDir, logFile, logCleanup, logAppend, logZip, sslParams, queues, topics));
	    debug("Added "+serverName+" "+ serverUrl+" "+ user+" "+logDir+" "+logFile+" queue monitors "+(queues==null?0:queues.size())+" topic monitors "+(topics==null?0:topics.size()));
	}
	else
	{
	    warn("EMS Server with alias "+serverName+" already exists, ignoring server at: "+serverUrl);
	}
    }

    public void loadServersFromFile(String xmlfile)
    {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db;
        try {
            db = dbf.newDocumentBuilder();

	    Document doc = db.parse(new File(xmlfile));

	    debug("Reading EMS server configuration file: "+xmlfile);

            Element xroot = doc.getDocumentElement();

	    readXmlElement(xroot);

        } catch (Exception e) {

	    error("reading config file: "+xmlfile+" "+e.toString());
	    System.exit(1);
        }
    }

    public void readXmlElement(Node xnode)
    {
    	try 
    	{
	    NodeList xnodes = xnode.getChildNodes();
	    if (xnodes != null)
	    {
		for (int i=0; i<xnodes.getLength(); i++)
		{
		    Node xn = xnodes.item(i);
		    if (xn.getNodeType()==Node.ELEMENT_NODE)
		    {
		    	if (xn.getNodeName().equals("ConnectionNode"))
		    	{	
			    String name = ((Element)xn).getAttribute("alias");
			    if (name == null || name.length() == 0)
			       name = ((Element)xn).getAttribute("name");
			    String url = ((Element)xn).getAttribute("url");
			    if (name == null || name.length() == 0)
			    {
				error("no alias specified for server at "+url);
				continue;
			    }
			    String user = ((Element)xn).getAttribute("user");
			    String passwd = ((Element)xn).getAttribute("encryptedPassword");
			    if (passwd != null && passwd.length() > 0)
			    {
				if (passwd.startsWith("#"))
				{
				    error("use of old style password encryption no longer supported, please resave passwords using GEMS 5.1 for server "+name);
				    passwd = ((Element)xn).getAttribute("password");
				}
				else
				{
				    try
				    {
					passwd = TibjmsAdmin.unmanglePassword(passwd);
				    }
				    catch(Throwable ex)
				    {
					error("unmangling password for server "+name+": "+ex.toString());
					passwd = ((Element)xn).getAttribute("password");
				    }
				}
			    }
			    else
				passwd = ((Element)xn).getAttribute("password");

			    String ld = ((Element)xn).getAttribute("logDir");
			    String lf = ((Element)xn).getAttribute("logFile");
			    if (url == null || url.length()==0)
				url = m_defaultURL;
			    if (user == null || user.length()==0)
				name = m_defaultUser;
			    if (passwd == null || passwd.length()==0)
				passwd = m_defaultPasswd;
			    if (ld == null || ld.length()==0)
				ld = m_defaultLogDir;
			    if (lf == null || lf.length()==0)
				lf = m_defaultLogFilename;
			    int lc=m_defaultLogClean;
			    String lcs = ((Element)xn).getAttribute("logCleanup");
			    try {
				if (lcs != null && lcs.length() > 0)
				    lc = Integer.parseInt(lcs);
			    }
			    catch(NumberFormatException e) {
				error("invalid value for logCleanup attribute for server "+name);
			    }
			    boolean la=true;
			    String las = ((Element)xn).getAttribute("logAppend");
			    if (las != null && las.length() > 0)
			       la = Boolean.valueOf(las).booleanValue();

			    boolean lz=true;
			    String lzs = ((Element)xn).getAttribute("logZip");
			    if (lzs != null && lzs.length() > 0)
			       lz = Boolean.valueOf(lzs).booleanValue();

				    
			    java.util.Map sslParams = null;
			    Hashtable<String, EmsDestination> queues=null;
			    Hashtable<String, EmsDestination> topics=null;
			    NodeList xns = xn.getChildNodes();
			    for (int j=0; xns!=null&&j<xns.getLength(); j++) 
			    {
				Node xn1 = xns.item(j);
				if (xn1.getNodeName().equals("SSLParam"))
				{
				    if (sslParams == null)
					sslParams = new Hashtable();

				    NamedNodeMap m = xn1.getAttributes();
				    Node t = m.getNamedItem("type");
				    if (t == null) t = m.getNamedItem("Type");
				    Node n = m.getNamedItem("name");
				    if (n == null) n = m.getNamedItem("Name");       
				    Node v = m.getNamedItem("value");
				    if (v == null) v = m.getNamedItem("Value");       
				    if (t != null && n != null && v != null)
				    {
					debug("Added SSLParam: "+n.getNodeValue()+"="+v.getNodeValue()+" for server "+name);
					if (t.getNodeValue().equalsIgnoreCase("string"))
					{
					    sslParams.put(n.getNodeValue(), v.getNodeValue());
					} else
					if (t.getNodeValue().equalsIgnoreCase("boolean"))
					{
					    sslParams.put(n.getNodeValue(), new Boolean(v.getNodeValue()));
					} else
					if (t.getNodeValue().equalsIgnoreCase("long"))
					{
					    sslParams.put(n.getNodeValue(), new Long(v.getNodeValue()));
					} else
					if (t.getNodeValue().equalsIgnoreCase("integer")||t.getNodeValue().equalsIgnoreCase("int"))
					{
					    sslParams.put(n.getNodeValue(), new Integer(v.getNodeValue()));
					}
				    }
				    else
					error("SSL Param must have Type, Name & Value attributes for server "+name);

				}
				else if (xn1.getNodeName().equals("QueueMonitor"))
				{
				    String p = ((Element)xn1).getAttribute("pattern");
				    if (p == null || p.length()==0)
				    {
					error("missing queue pattern in queue monitor for server "+name);
					continue;
				    }
				    if (p.equals(">"))
					warn("using wildcard pattern > for server "+name+" with many queues can affect sever performance");
				    int permType = m_defaultDestPermType;
				    String ts = ((Element)xn1).getAttribute("type");
				    if (ts != null && ts.length() > 0)
				    {
					if (ts.equalsIgnoreCase("both"))
					    permType = DestinationInfo.DEST_GET_NOTEMP;
					else if (ts.equalsIgnoreCase("dynamic"))
					    permType = DestinationInfo.DEST_GET_DYNAMIC;
				    }
				    String ld1 = ((Element)xn1).getAttribute("logDir");
				    String lf1 = ((Element)xn1).getAttribute("logFile");
				    if (ld1 == null || ld1.length()==0)
					ld1 = ld;
				    if (lf1 == null || lf1.length()==0)
				    {
					int li = lf.lastIndexOf(".");
					if (li > 0)
					    lf1 = lf.substring(0,li)+"-Queues"+lf.substring(li);
					else
					    lf1 = lf+"-Queues";
				    }
				    else
				    if (lf1.equalsIgnoreCase(lf))
				    {
					error("QueueMonitor log filename "+lf1+" must be different to server log filename for pattern "+p+" server "+name);
					continue;
				    }
				    int lc1=m_defaultLogClean;
				    String lcs1 = ((Element)xn1).getAttribute("logCleanup");
				    try {
					if (lcs1 != null && lcs1.length() > 0)
					    lc1 = Integer.parseInt(lcs1);
				    }
				    catch(NumberFormatException e) {
					error("invalid value for logCleanup attribute for queue pattern "+p+" server "+name);
				    }
				    boolean la1=true;
				    String la1s = ((Element)xn1).getAttribute("logAppend");
				    if (la1s != null && la1s.length() > 0)
				       la1 = Boolean.valueOf(la1s).booleanValue();

				    boolean lz1=true;
				    String lz1s = ((Element)xn1).getAttribute("logZip");
				    if (lz1s != null && lz1s.length() > 0)
				       lz1 = Boolean.valueOf(lz1s).booleanValue();

				    if (queues == null)
					queues = new Hashtable<String, EmsDestination>();
				    if (queues.containsKey(p))
				    {
					error("duplicate queue pattern "+p+" in queue monitor for server "+name);
					continue;
				    }
				    queues.put(p, new EmsDestination(p, permType, ld1, lf1, lc1, la1, lz1));

				}
				else if (xn1.getNodeName().equals("TopicMonitor"))
				{
				    String p = ((Element)xn1).getAttribute("pattern");
				    if (p == null || p.length()==0)
				    {
					error("missing topic pattern in topic monitor for server "+name);
					continue;
				    }
				    if (p.equals(">"))
					warn("using wildcard pattern > for server "+name+" with many topics can affect sever performance");
				    int permType = m_defaultDestPermType;
				    String ts = ((Element)xn1).getAttribute("type");
				    if (ts != null && ts.length() > 0)
				    {
					if (ts.equalsIgnoreCase("both"))
					    permType = DestinationInfo.DEST_GET_NOTEMP;
					else if (ts.equalsIgnoreCase("dynamic"))
					    permType = DestinationInfo.DEST_GET_DYNAMIC;
				    }
				    String ld1 = ((Element)xn1).getAttribute("logDir");
				    String lf1 = ((Element)xn1).getAttribute("logFile");
				    if (ld1 == null || ld1.length()==0)
					ld1 = ld;
				    if (lf1 == null || lf1.length()==0)
				    {
					int li = lf.lastIndexOf(".");
					if (li > 0)
					    lf1 = lf.substring(0,li)+"-Topics"+lf.substring(li);
					else
					    lf1 = lf+"-Topics";
				    }
				    else
				    if (lf1.equalsIgnoreCase(lf))
				    {
					error("TopicMonitor log filename "+lf1+" must be different to server log filename for pattern "+p+" server "+name);
					continue;
				    }
				    int lc1=m_defaultLogClean;
				    String lcs1 = ((Element)xn1).getAttribute("logCleanup");
				    try {
					if (lcs1 != null && lcs1.length() > 0)
					    lc1 = Integer.parseInt(lcs1);
				    }
				    catch(NumberFormatException e) {
					error("invalid value for logCleanup attribute for topic pattern "+p+" server "+name);
				    }
				    boolean la1=true;
				    String la1s = ((Element)xn1).getAttribute("logAppend");
				    if (la1s != null && la1s.length() > 0)
				       la1 = Boolean.valueOf(la1s).booleanValue();

				    boolean lz1=true;
				    String lz1s = ((Element)xn1).getAttribute("logZip");
				    if (lz1s != null && lz1s.length() > 0)
				       lz1 = Boolean.valueOf(lz1s).booleanValue();

				    Enumeration<EmsDestination> de;
				    EmsDestination d;
				    boolean skip=false;
				    for (d=null, de = queues.elements(); de.hasMoreElements();)
				    {
					d = de.nextElement();
					if (lf1.equalsIgnoreCase(d.m_logFilename))
					{
					    error("TopicMonitor log filename "+lf1+" must be different to queue monitor log filename for pattern "+p+" server "+name);
					    skip=true;
					    break;
					}
				    }
				    if (skip)
					continue;

				    if (topics == null)
					topics = new Hashtable<String, EmsDestination>();
				    if (topics.containsKey(p))
				    {
					error("duplicate topic pattern "+p+" in topic monitor for server "+name);
					continue;
				    }
				    topics.put(p, new EmsDestination(p, permType, ld1, lf1, lc1, la1, lz1));

				}
			    }
			    if (queues == null && ((Element)xn).hasAttribute("queueNamePattern"))
			    {
				warn("GEMS servers.xml style queueNamePattern not supported, please add QueueMonitor elements for the specific queues to be monitored");
			    }
			    if (topics == null && ((Element)xn).hasAttribute("topicNamePattern"))
			    {
				warn("GEMS servers.xml style topicNamePattern not supported, please add TopicMonitor elements for the specific topics to be monitored");
			    }
		
			    addConnection(name, url, user, passwd, ld, lf, lc, la, lz, sslParams, queues, topics);
			} 
			else
			{
			    readXmlElement(xn);
			}

		    }
		}
	    }
        } catch (Exception e) {

	    error("processing XML config: "+e.getMessage());
	    System.exit(1);
        }
    }

    class ConnectThread extends Thread 
    {
	long m_delay;
	long start,end;

    	ConnectThread(long delay)
    	{
            m_delay = delay*1000;
    	}

    	public void run()
    	{
	    while (true)
	    {
		start = System.nanoTime();
		EmsServer con;
		Enumeration<EmsServer> e;
		for (con=null, e = m_servers.elements(); e.hasMoreElements();)
		{
		    con = e.nextElement();
		    TibjmsAdmin adminConn = null;
		    try
		    {
			if (con.m_adminConn == null)
			{

			    if (con.m_serverUrl.startsWith("ssl"))
				adminConn = new TibjmsAdmin(con.m_serverUrl, con.m_user, con.m_password, con.m_sslParams);
			    else
				adminConn = new TibjmsAdmin(con.m_serverUrl, con.m_user, con.m_password);
			    adminConn.setCommandTimeout(5000);

			    if (con.m_staleConn != null)
			    {
				// Clean up old stale connection
				try { 
				    con.m_staleConn.close();
				    con.m_staleConn = null;
				    debug("Cleaned up stale connection to server "+con.m_alias);
				} catch (TibjmsAdminException e1)
				{
				    debug("Failed to clean up stale connection to server "+con.m_alias +" "+e1.toString());
				    con.m_staleConn = null;
				}
			    }

			    StateInfo stateInfo =  adminConn.getStateInfo();

			    if (stateInfo != null)
			    {
				info("Connected to EMS "+ (stateInfo.isAppliance()?"Appliance: ":"Server: ")+stateInfo.getServerName()+" V"+stateInfo.getVersionInfo().toString()+" at "+con.m_serverUrl+" alias: "+con.m_alias);

				if (stateInfo != null && (stateInfo.getState().get() & com.tibco.tibjms.admin.State.SERVER_STATE_STANDBY) != 0)
				{
				    // Connected to standby, try reconnecting to primary by swapping servers in URL
				    String url = con.m_serverUrl;
				    String testString = con.m_serverUrl;
				    // We need to support 4 server URL, find number of , in URL to determine no of attempts
				    int attempts = testString.length() - testString.replace(",", "").length();
				    
				    for (int i=0;i<attempts;i++)
				    {
					int ci = url.indexOf(',');
					if (ci > 0)
					{
					    adminConn.close();
					    adminConn = null;

					    String u = url.substring(ci+1);
					    u += ",";
					    u += url.substring(0,ci);
					    url = u;

					    debug("connected to standby server "+con.m_alias+", attempting to reconnect to active server at "+u);
					    if (con.m_serverUrl.startsWith("ssl"))
						adminConn = new TibjmsAdmin(u, con.m_user, con.m_password, con.m_sslParams);
					    else
						adminConn = new TibjmsAdmin(u, con.m_user, con.m_password);
					    adminConn.setCommandTimeout(5000);
					    stateInfo =  adminConn.getStateInfo();
					    if (stateInfo != null && (stateInfo.getState().get() & com.tibco.tibjms.admin.State.SERVER_STATE_STANDBY) != 0)
					    {
						debug("Still connected to standby server("+u+"), retrying...");
					    }
					    else
					    {
						debug("Connected to active server "+con.m_alias+" at "+u);
						break;
					    }

					}
				    }
				}
			    }
			    else
			    {
				warn("getSateInfo for "+con.m_alias+" returned null, upgrade to EMS client 8.1 greater");
			    }

			    con.m_adminConn = adminConn;
			}

		    }
		    catch(TibjmsAdminException ex)
		    {
			warn("Connect failed to Server "+con.m_alias+" "+ex.toString());
			try { if (adminConn != null) adminConn.close(); } catch (TibjmsAdminException e1) {}
		    }
		    catch(Exception ex1)
		    {
			warn("Connect failed to Server "+con.m_alias+" "+ex1.toString());
			try { if (adminConn != null) adminConn.close(); } catch (TibjmsAdminException e1) {}
		    }
		}

		if (!m_cleanupLogs.isEmpty())
		    cleanupLogs(m_cleanupLogs.remove(0));

		end = System.nanoTime();
		long sleepTime = m_delay - (start-end)/1000000;
		try 
		{
		    if (sleepTime > 0)
			Thread.sleep(sleepTime);
		} 
		catch (InterruptedException ex) {}

	    }
	}
    }
    public void run() {

	long start=0,end;
	long pollStart,pollEnd;

	m_connectThread.start();

	try 
	{
	    Thread.sleep(5000);
	} 
	catch (InterruptedException ex) {}

	while (true)
	{
	    pollStart = System.nanoTime();
	    EmsServer con;
	    Enumeration<EmsServer> e;
	    for (con=null, e = m_servers.elements(); e.hasMoreElements();)
	    {
		con = e.nextElement();
		if (con.m_adminConn != null)
		{
		    long respTime = 0;

		    try
		    {
			Date timestamp = null;
			try 
			{
			    start = System.nanoTime();
			    con.m_serverInfo =  con.m_adminConn.getInfo();
			    end = System.nanoTime();
			    timestamp = new Date();
			    respTime = (end-start)/1000000;

			}
			catch(TibjmsAdminSecurityException se)
			{
			    con.m_serverInfo = null;
			}

			if (con.m_serverInfo != null && (con.m_serverInfo.getStateObj().get() & com.tibco.tibjms.admin.State.SERVER_STATE_ACTIVE) != 0)
			{

			    getQueueStats(con);
			    getTopicStats(con);

			    Hashtable stats = new Hashtable();
			    getStatsMethodValues(stats, con.m_serverInfo, null);
			    doServerLogging(con.m_alias, stats, timestamp, respTime);

			    int qc=0;
			    if (con.m_queues != null)
			    {
				Enumeration<EmsDestination> de;
				EmsDestination d;
				for (d=null, de = con.m_queues.elements(); de.hasMoreElements();)
				{
				    d = de.nextElement();
				    for (int i=0;i < d.m_info.length;i++)
				    {
					stats = new Hashtable();
					getStatsMethodValues(stats, d.m_info[i], null);
					getStatsMethodValues(stats, d.m_info[i].getInboundStatistics(), "inbound");
					getStatsMethodValues(stats, d.m_info[i].getOutboundStatistics(), "outbound");
					doDestinationLogging(con.m_alias, d.m_pattern, d.m_info[i].getName(), stats, timestamp, true);
					qc++;
				    }
				}
			    }

			    int tc=0;
			    if (con.m_topics != null)
			    {
				Enumeration<EmsDestination> de;
				EmsDestination d;
				for (d=null, de = con.m_topics.elements(); de.hasMoreElements();)
				{
				    d = de.nextElement();
				    for (int i=0;i < d.m_info.length;i++)
				    {
					stats = new Hashtable();
					getStatsMethodValues(stats, d.m_info[i], null);
					getStatsMethodValues(stats, d.m_info[i].getInboundStatistics(), "inbound");
					getStatsMethodValues(stats, d.m_info[i].getOutboundStatistics(), "outbound");
					doDestinationLogging(con.m_alias, d.m_pattern, d.m_info[i].getName(), stats, timestamp, false);
					tc++;
				    }
				}
			    }

			    debug("Collected server stats for server "+con.m_alias+" queues: "+qc+" topics: "+tc+" at "+timestamp+" response time(ms): "+respTime);

			}
			else
			    warn("Server "+con.m_alias+" in standby mode, logging will not start until server is active");

		    }
		    catch(TibjmsAdminException ex)
		    {
			if (ex.toString().contains("Timeout"))
			{
			    if (start > 0)
			    {
				end = System.nanoTime();
				respTime = (end-start)/1000000;
			    }
			    // Clean up later..
			    con.m_staleConn = con.m_adminConn;
			    con.close();
			    serverDisconnected(con, " timeout after "+respTime+"(ms) "+ex.toString());
			}
			else
			{
			    con.close();
			    serverDisconnected(con, ex.toString());
			}
		    }
		    catch(Exception ex1)
		    {
			con.close();
			serverDisconnected(con, ex1.toString());
		    }
		}
	    }
	    pollEnd = System.nanoTime();
	    long sleepTime = (m_interval * 1000) - (pollEnd-pollStart)/1000000;
	    try 
	    {
		if (sleepTime > 0)
		{
		    Thread.sleep(sleepTime);
		}
		else
		    warn("poll time exceeded interval by "+(-sleepTime)+"ms");
	    } 
	    catch (InterruptedException ex) {}

	}
    }

    public void serverDisconnected(EmsServer con, String reason)
    {
	warn("Disconnected from Server "+con.m_alias+" "+reason);
    }

    public void doServerLogging(String serverName, Hashtable statsValues, Date timestamp, long respTime)
    {

	EmsServer con = m_servers.get(serverName);
	if (con == null)
	{
	    error("failed to find connection for server "+serverName);
	    return;
	}

	String filename = con.m_logFilename;
	try
	{
	    if (filename.contains("$N"))
		filename = filename.replace("$N",stripSpaces(serverName));

	    if (filename.contains("$D"))
		filename = filename.replace("$D", m_fileDateFormat.format(timestamp).toString());

	    if (con.m_logFile == null || !con.m_logFile.getName().endsWith(filename))
	    {
		if (con.m_filePrint != null)
		    con.m_filePrint.close();
		if (con.m_fileOut != null)
		    con.m_fileOut.close();

		if (con.m_logFile != null && con.m_logZip)
		    zipLogFile(con.m_logFile.getPath());

		info("Logging server stats for server "+con.m_alias+" to log file "+con.m_logDir+"/"+filename);

		File f = new File(con.m_logDir);
		f.mkdirs();
		con.m_logFile = new File(f, filename);
		boolean exists = con.m_logFile.exists();
		con.m_fileOut = new FileOutputStream(con.m_logFile, con.m_logAppend);
		con.m_filePrint  = new PrintStream(con.m_fileOut);

		if (!exists || !con.m_logAppend)
		{
		    StringBuffer  b= new StringBuffer ("timestamp");
		    b.append(m_csvDelim);
		    b.append ("server");
		    b.append(m_csvDelim);
		    for ( int j = 0; j < m_serverStatsNames.size(); j++ ) {
			b.append(m_serverStatsNames.get(j));
			b.append(m_csvDelim);
		    }
		    b.append("responseTimeMillis");
		    con.m_filePrint.println( b.toString() );

		}
		if (con.m_logCleanup > 0)
		    m_cleanupLogs.addElement(con);
	    }
	}
	catch(IOException ie)
	{
	    error("Failed to write to logfile "+filename+" "+ie.getMessage());
	    return;
	}

	if (con.m_filePrint != null)
	{
	    StringBuffer  b= new StringBuffer (m_timestampFormat.format(timestamp).toString());
	    b.append(m_csvDelim);
	    b.append(con.m_alias);
	    b.append(m_csvDelim);
	    for ( int j = 0; j < m_serverStatsNames.size(); j++ ) {
		b.append(statsValues.get(m_serverStatsNames.get(j)));
		b.append(m_csvDelim);
	    }
	    b.append(respTime);
	    con.m_filePrint.println( b.toString() );
	}
    }

    public void doDestinationLogging(String serverName, String pattern, String destName, Hashtable statsValues, Date timestamp, boolean isQueue)
    {

	EmsServer con = m_servers.get(serverName);
	if (con == null)
	{
	    error("failed to find connection for server "+serverName);
	    return;
	}
	EmsDestination d;
	if (isQueue)
	    d=con.m_queues.get(pattern);
	else
	    d=con.m_topics.get(pattern);

	if (d == null)
	{
	    error("failed to find destination pattern "+pattern+" for server "+serverName);
	    return;
	}

	String filename = d.m_logFilename;
	try
	{
	    if (filename.contains("$N"))
		filename = filename.replace("$N",stripSpaces(serverName));

	    if (filename.contains("$D"))
		filename = filename.replace("$D", m_fileDateFormat.format(timestamp).toString());

	    if (d.m_logFile == null || !d.m_logFile.getName().endsWith(filename))
	    {
		if (d.m_filePrint != null)
		    d.m_filePrint.close();
		if (d.m_fileOut != null)
		    d.m_fileOut.close();

		if (d.m_logFile != null && d.m_logZip)
		    zipLogFile(d.m_logFile.getPath());

		info("Logging "+(isQueue?"queue":"topic")+" stats for pattern "+pattern+" server "+con.m_alias+" to log file "+d.m_logDir+"/"+filename);

		File f = new File(d.m_logDir);
		f.mkdirs();
		d.m_logFile = new File(f, filename);
		boolean exists = d.m_logFile.exists();
		d.m_fileOut = new FileOutputStream(d.m_logFile, d.m_logAppend);
		d.m_filePrint  = new PrintStream(d.m_fileOut);

		if (!exists || !d.m_logAppend)
		{
		    StringBuffer  b= new StringBuffer ("timestamp");
		    b.append(m_csvDelim);
		    b.append ("server");
		    b.append(m_csvDelim);
		    if(isQueue)
		    {
			b.append ("Queue");
			b.append(m_csvDelim);
			for ( int j = 0; j < m_queueStatsNames.size(); j++ ) {
			    b.append(m_queueStatsNames.get(j));
			    if (j <  m_queueStatsNames.size() -1)
				b.append(m_csvDelim);
			}
		    }
		    else
		    {
			b.append ("Topic");
			b.append(m_csvDelim);
			for ( int j = 0; j < m_topicStatsNames.size(); j++ ) {
			    b.append(m_topicStatsNames.get(j));
			    if (j <  m_topicStatsNames.size() -1)
				b.append(m_csvDelim);
			}
		    }
		    d.m_filePrint.println( b.toString() );

		}
		if (d.m_logCleanup > 0)
		    m_cleanupLogs.addElement(d);
	    }
	}
	catch(IOException ie)
	{
	    error("Failed to write to logfile "+filename+" "+ie.getMessage());
	    return;
	}

	if (d.m_filePrint != null)
	{
	    StringBuffer  b= new StringBuffer (m_timestampFormat.format(timestamp).toString());
	    b.append(m_csvDelim);
	    b.append(con.m_alias);
	    b.append(m_csvDelim);
	    b.append(destName);
	    b.append(m_csvDelim);
	    if(isQueue)
	    {
		for ( int j = 0; j < m_queueStatsNames.size(); j++ ) {
		    b.append(statsValues.get(m_queueStatsNames.get(j)));
		    if (j <  m_queueStatsNames.size() -1)
			b.append(m_csvDelim);
		}
	    }
	    else
	    {
		for ( int j = 0; j < m_topicStatsNames.size(); j++ ) {
		    b.append(statsValues.get(m_topicStatsNames.get(j)));
		    if (j <  m_topicStatsNames.size() -1)
			b.append(m_csvDelim);
		}
	    }
	    d.m_filePrint.println( b.toString() );
	}
    }

    public void getQueueStats(EmsServer con)
    {
	if (con.m_adminConn == null || con.m_queues == null)
		return;


	Enumeration<EmsDestination> de;
	EmsDestination d;
	for (d=null, de = con.m_queues.elements(); de.hasMoreElements();)
	{
	    d = de.nextElement();
	    QueueInfo[] di=null;
	    d.m_info = null;
	    try {

		di=con.m_adminConn.getQueues(d.m_pattern, d.m_destPermType, TibjmsAdmin.DEST_CURSOR_FIRST, m_destCursorSize);
		while (di != null)
		{
		    d.m_info = concatArrays(d.m_info, di);
		    di = con.m_adminConn.getQueues(d.m_pattern, d.m_destPermType, TibjmsAdmin.DEST_CURSOR_NEXT, m_destCursorSize);
		}
	    }
	    catch (Throwable e)
	    {
		if (e instanceof TibjmsAdminException)
		{
		    if (e.getMessage().endsWith("server does not support that command."))
		    {
			error("server "+con.m_alias+" does not support use of getQueues with cursors, disabling queue monitoring");
			// remove queue entry
			con.m_queues.clear();
			return;
		    }
		    // Always throws "No active cursor" excep on next call, if all queues returned in first call.
		    // So make sure we ignore this case bug.

		    if (!e.getMessage().endsWith("No active cursor"))
		    {
			error("calling getQueues for server "+con.m_alias+" pattern "+d.m_pattern+" "+e.getMessage());
			try {
			    // Ensure cursor is closed
			    con.m_adminConn.getQueues(d.m_pattern, d.m_destPermType, TibjmsAdmin.DEST_CURSOR_LAST, 1);
			} catch (Throwable xx) {}
		    }

		}
		else
		{
		    error(e.toString()+" disabling queue monitoring for server "+con.m_alias);
		    // We can get here for old API's that have no cursor option
		    con.m_queues.clear();
		    return;
		}
	    }
	    if (d.m_info.length >= m_maxDestinations)
		warn("getQueues for server "+con.m_alias+" pattern "+d.m_pattern+" returned many queues: "+d.m_info.length);
	}
    }

    public void getTopicStats(EmsServer con)
    {
	if (con.m_adminConn == null || con.m_topics == null)
		return;


	Enumeration<EmsDestination> de;
	EmsDestination d;
	for (d=null, de = con.m_topics.elements(); de.hasMoreElements();)
	{
	    d = de.nextElement();
	    TopicInfo[] di=null;
	    d.m_info = null;
	    try {

		di=con.m_adminConn.getTopics(d.m_pattern, d.m_destPermType, TibjmsAdmin.DEST_CURSOR_FIRST, m_destCursorSize);
		while (di != null)
		{
		    d.m_info = concatArrays(d.m_info, di);
		    di = con.m_adminConn.getTopics(d.m_pattern, d.m_destPermType, TibjmsAdmin.DEST_CURSOR_NEXT, m_destCursorSize);
		}
	    }
	    catch (Throwable e)
	    {
		if (e instanceof TibjmsAdminException)
		{
		    if (e.getMessage().endsWith("server does not support that command."))
		    {
			error("server "+con.m_alias+" does not support use of getTopics with cursors, disabling topic monitoring");
			con.m_topics.clear();
			return;
		    }
		    // Always throws "No active cursor" excep on next call, if all topics returned in first call.
		    // So make sure we ignore this case bug.

		    if (!e.getMessage().endsWith("No active cursor"))
		    {
			error("calling getTopics for server "+con.m_alias+" pattern "+d.m_pattern+" "+e.getMessage());
			try {
			    // Ensure cursor is closed
			    con.m_adminConn.getTopics(d.m_pattern, d.m_destPermType, TibjmsAdmin.DEST_CURSOR_LAST, 1);
			} catch (Throwable xx) {}
		    }

		}
		else
		{
		    error(e.toString()+" disabling topic monitoring for server "+con.m_alias);
		    // We can get here for old API's that have no cursor option
		    con.m_topics.clear();
		    return;
		}
	    }
	    if (d.m_info.length >= m_maxDestinations)
		warn("getTopics for server "+con.m_alias+" pattern "+d.m_pattern+" returned many topics: "+d.m_info.length);
	}
    }

    public String stripSpaces(String source) {
        return source.replaceAll("\\s+", "");
    }

    public static <T> T[] concatArrays(T[] first, T[] second) 
    {
	if (first == null)
	    return second;

	if (second == null)
	    return first;

	T[] result = Arrays.copyOf(first, first.length + second.length);
	System.arraycopy(second, 0, result, first.length, second.length);
	return result;
    }

    public void getStatsMethodNames(Vector v, Class c, String prefix)
    {
      
	Method[] methods = c.getMethods();
	for (int i=0; i<methods.length; i++ )
	{
	    String methodName = methods[i].getName();
	    if (matchStatsMethod(methods[i], methodName))
	    {
		String displayName = getStatsDisplayName(methodName);
		if (prefix != null && prefix.length() > 0)
		{
		    displayName = prefix+Character.toUpperCase(displayName.charAt(0)) + displayName.substring(1);
		}
		v.add(displayName);
	    }
	}
    }
   
    public void zipLogFile(String filepath)
    {
	try
	{
	    File f = new File(filepath);

	    if (f.exists())
	    {
		FileInputStream fis=new FileInputStream(filepath);
		FileOutputStream fos=new FileOutputStream(filepath+".gzip");
		GZIPOutputStream dos=new GZIPOutputStream(fos);

		int data;
		while ((data=fis.read())!=-1)
		{
		    dos.write(data);
		}
		dos.close();
		fis.close();
		fos.close();
		if (!f.delete())
		    warn("Failed to remove log file after zipping: "+filepath);
	    }
	}
	catch(IOException ex)
	{

    	   error("zipLogFile: "+ex.toString());
    	}
    }

    public void cleanupLogs(EmsLogEntry e)
    {
	File dir = new File(e.m_logDir);
	if(dir.exists())
	{

	    int i = e.m_logFilename.lastIndexOf('.');
	    if (i <= 0)
	    {
		error("cannot clean logs in dir "+e.m_logDir+" no filename extension for file: "+e.m_logFilename);
		e.m_logCleanup = 0;
		m_cleanupLogs.removeElement(e);
	    }
	    String ext = e.m_logFilename.substring(i);
	    debug("Cleaning up all logs in dir "+e.m_logDir+" with ext "+ext+" older than "+e.m_logCleanup+" days");
	    File[] listFiles = dir.listFiles(new FileExtFilter(ext, e.m_logZip));           
	    long purgeTime = System.currentTimeMillis() - ((long)e.m_logCleanup * 24 * 60 * 60 * 1000);
	    for(File listFile : listFiles)
	    {
		if(listFile.lastModified() < purgeTime)
		{
		    if (!listFile.delete())
		    {
			warn("unable to delete log file: " + listFile);
		    }
		    else
		    {
			debug("Deleted log file: " + listFile+" not modified for > "+e.m_logCleanup+" days");
		    }
		}
	    }
	}
	else
	{
	    debug("Dir to cleanup logs does not exist: "+e.m_logDir);
	    m_cleanupLogs.removeElement(e);
	}

    }

    public class FileExtFilter implements FilenameFilter
    {
	private String ext;
	private boolean doZip;
	public FileExtFilter(String ext, boolean doZip) {
	    this.ext = ext;
	    this.doZip = doZip;
	}
	public boolean accept(File dir, String name) {
	    return (name.endsWith(ext) || (doZip && name.endsWith(ext+".gzip")));
	}
    }

    public void getStatsMethodValues(Hashtable h, Object obj, String prefix)
    {
	Class c = obj.getClass();

	Method[] methods = c.getMethods();
	for (int i=0; i<methods.length; i++ )
	{
	    String methodName = methods[i].getName();
	    if (matchStatsMethod(methods[i], methodName))
	    {
		try {
		    String displayName = getStatsDisplayName(methodName);
		    if (prefix != null && prefix.length() > 0)
		    {
			displayName = prefix+Character.toUpperCase(displayName.charAt(0)) + displayName.substring(1);
		    }
		    Object ret = methods[i].invoke(obj, (java.lang.Object[])null);
		    h.put(displayName, ret);
		}
		catch (Throwable e) {
		    error(e.getClass()+": "+e.getMessage());
		}
	    }
	}
    }

    // Returns if ServerInfo method returns a stats value that should be logged.
    public boolean matchStatsMethod(Method method, String methodName)
    {
	if (methodName.startsWith( "get" ))
	{
	    Class[] parameterTypes = method.getParameterTypes();
	    if (parameterTypes.length > 0 )
	    {
		return false;
	    }

	    int modifiers = method.getModifiers();
	    if (!Modifier.isTransient( modifiers ) )
	    {
		if(method.getReturnType().getName().equals("long") || method.getReturnType().getName().equals("int"))
		{
		    if ((methodName.contains("MsgMem")||methodName.endsWith("Size") || methodName.endsWith("Count")||methodName.endsWith("Rate") ||
		    	methodName.endsWith("TotalMessages") || methodName.endsWith("TotalBytes")) &&
			(!methodName.contains("Log")) && (!methodName.contains("Trace")) && (!methodName.contains("SSL")) && (!methodName.contains("Max")) && 
			(!methodName.contains("MessagePool")))
		    {
			// Check exclusion list
			for (int i=0;i<m_methodExclusionList.length;i++)
			{
			    if (methodName.endsWith(m_methodExclusionList[i]))
				return false;
			}
			return true;
		    }
		}
	    }
	}
	return false;
    }

    // Returns stats display name from ServerInfo method name
    public String getStatsDisplayName(String methodName)
    {

	String displayName;
	if (Character.isLowerCase(methodName.charAt(4)))
	    displayName = Character.toLowerCase( methodName.charAt(3) ) + methodName.substring(4);
	else
	    displayName = methodName.substring(3);
	return displayName;
    }

    public static void main(String[] args)
    {
        EmsStatsLogger t = new EmsStatsLogger(args);
    }

    public void debug(String s)
    {
	if (m_debug)
            System.out.println("Debug: "+s);
    }
    public void info(String s)
    {
	System.out.println("Info: "+s);
    }
    public void warn(String s)
    {
	System.out.println("Warning: "+s);
    }
    public void error(String s)
    {
	System.out.println("Error: "+s);
    }
    public int parseArg(String[] args, int i)
    {
        if (i < args.length)
        {
            if (args[i].compareTo("-interval")==0)
            {
                if ((i+1) >= args.length) usage();
                try {
                    m_interval = Integer.parseInt(args[i+1]);
                }
                catch(NumberFormatException e) {
                    error("invalid value for -interval parameter");
                    usage();
                }
		if (m_interval < m_minInterval)
		{
		    m_interval = m_minInterval;
                    warn("invalid value for -interval parameter, using "+m_interval);
		}
                return 1;
            }
	    else
            if (args[i].compareTo("-config")==0)
            {
                if ((i+1) >= args.length) usage();
                m_configFile = args[i+1];
                return 1;
            }
            else
            if (args[i].compareTo("-help")==0)
            {
                usage();
            }
            else
            if (args[i].compareTo("-debug")==0)
            {
                m_debug = true;
                return 0;
            }
        }
	return -1;
    }
    public void parseArgs(String[] args)
    {
        for (int i = 0; i < args.length; i++)
        {
	    int inc = parseArg(args, i);
	    if (inc >= 0)
	    {
		i += inc;
	    }
	    else
            {
                usage();
            }
        }
    }
    public void usage()
    {
        usage("\nUsage: java EmsStatsLogger [options]", true);
    }
    public void usage(String header, boolean doExit)
    {
        System.out.println(header);
        System.out.println("");
        System.out.println("   where options are:");
        System.out.println("");
        System.out.println("  -config      <config file>     - Server config filename, default servers.xml");
        System.out.println("  -interval    <secs>            - Interval between log entries, default 30 seconds");
        System.out.println("  -debug                         - Enable debug trace to stdout");
	if (doExit)
	    System.exit(0);
    }
}


