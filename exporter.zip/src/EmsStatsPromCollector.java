/* Copyright (c) 2017-2018 TIBCO Software Inc.
 * All rights reserved.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 * 
 * TIBCO EMS Server Statistics Prometheus Collector
 *
 * Uses EMS Admin API to collect server info, queue and topic stats and provide them to Prometheus.
 *
 * Compile with:
 *	- EMS client API V8.1 or greater; tibjmsadmin.jar
 *	- Prometheus simpleclient, simpleclient_common and simpleclient_httpserver available at:
 * 		https://github.com/prometheus/client_java
 *
 * @author rlawrence
 * 
 */

import java.util.Hashtable;
import java.util.Set;
import java.util.Arrays;
import java.util.Vector;
import java.io.IOException;
import java.util.Date;
import java.net.InetSocketAddress;
import com.tibco.tibjms.admin.*;

import io.prometheus.client.*;
import io.prometheus.client.exporter.HTTPServer;

public class EmsStatsPromCollector extends EmsStatsLogger 
{

    // By default all statistics are treated as Gauges, which is a metric that represents a single numerical value that can arbitrarily go up and down
    // List here the stats that are to be treated as Counter types by Prometheus
    // A counter is a cumulative metric that represents a single numerical value that only ever goes up

    protected String[] m_statsCounterTypes = {
	"inboundMessageCount",
	"outboundMessageCount",
	"inboundTotalMessages",
	"outboundTotalMessages",
	"inboundTotalBytes",
	"outboundTotalBytes"
    };


    protected int m_serverStatsPort =  9091;
    protected int m_queueStatsPort =  9092;
    protected int m_topicStatsPort =  9093;
    protected boolean m_nolog =  false;
    protected String m_jobName  =  "TIB-EMS";
    protected HTTPServer m_serverHTTPServer=null;
    protected HTTPServer m_queueHTTPServer=null;
    protected HTTPServer m_topicHTTPServer=null;
    protected Hashtable<String, SimpleCollector>  m_serverCollectors=  new Hashtable<String, SimpleCollector>();
    protected Hashtable<String, SimpleCollector>  m_queueCollectors=  new Hashtable<String, SimpleCollector>();
    protected Hashtable<String, SimpleCollector>  m_topicCollectors=  new Hashtable<String, SimpleCollector>();
    protected Gauge m_respTimeGauge;
    protected String m_promGatewayURL = null;
    protected CollectorRegistry m_serverRegistry =  null;
    protected CollectorRegistry m_queueRegistry =  null;
    protected CollectorRegistry m_topicRegistry =  null;

    public EmsStatsPromCollector(String[] args) {

	m_interval = 60;
        parseArgs(args);
	init();
    	run();
    }

    public void init()
    {
	super.init();

	m_serverRegistry =  new CollectorRegistry();

	for ( int j = 0; j < m_serverStatsNames.size(); j++ ) {
	    SimpleCollector c;
	    String n = m_serverStatsNames.get(j);
	    if (Arrays.asList(m_statsCounterTypes).contains(n))
		c = Counter.build().name("ems:"+n).help(n).labelNames("job","instance").register(m_serverRegistry);
	    else
		c = Gauge.build().name("ems:"+n).help(n).labelNames("job","instance").register(m_serverRegistry);
	    if (c == null)
	    {
		error("Failed to create Prometheus collector for server metric: "+n);
		System.exit(1);
	    }
	    m_serverCollectors.put(n,c);

	}
	m_respTimeGauge = Gauge.build().name("ems:responseTimeMillis").help("Response time (millis)").labelNames("job","instance").register(m_serverRegistry);

	m_queueRegistry =  new CollectorRegistry();
	for ( int j = 0; j < m_queueStatsNames.size(); j++ ) {
	    SimpleCollector c;
	    String n = m_queueStatsNames.get(j);
	    if (Arrays.asList(m_statsCounterTypes).contains(n))
		c = Counter.build().name("ems:queue:"+n).help(n).labelNames("job","instance","queue").register(m_queueRegistry);
	    else
		c = Gauge.build().name("ems:queue:"+n).help(n).labelNames("job","instance","queue").register(m_queueRegistry);
	    if (c == null)
	    {
		error("Failed to create Prometheus collector for queue metric: "+n);
		System.exit(1);
	    }
	    m_queueCollectors.put(n,c);

	}
	m_topicRegistry =  new CollectorRegistry();
	for ( int j = 0; j < m_topicStatsNames.size(); j++ ) {
	    SimpleCollector c;
	    String n = m_topicStatsNames.get(j);
	    if (Arrays.asList(m_statsCounterTypes).contains(n))
		c = Counter.build().name("ems:topic:"+n).help(n).labelNames("job","instance","topic").register(m_topicRegistry);
	    else
		c = Gauge.build().name("ems:topic:"+n).help(n).labelNames("job","instance","topic").register(m_topicRegistry);
	    if (c == null)
	    {
		error("Failed to create Prometheus collector for topic metric: "+n);
		System.exit(1);
	    }
	    m_topicCollectors.put(n,c);

	}

	if (m_serverStatsPort > 0)
	{
	    try
	    {
		m_serverHTTPServer = new HTTPServer(new InetSocketAddress(m_serverStatsPort), m_serverRegistry);
		info("Started Prometheus client HTTPServer on port "+m_serverStatsPort+" for EMS server stats collection");
	    }
	    catch (IOException ex)
	    {
		error("creating Prometheus HTTPServer on port "+m_serverStatsPort+" "+ex.toString());
		System.exit(1);
	    }
	}
	if (m_queueStatsPort > 0)
	{
	    try
	    {
		m_queueHTTPServer = new HTTPServer(new InetSocketAddress(m_queueStatsPort), m_queueRegistry);
		info("Started Prometheus client HTTPServer on port "+m_queueStatsPort+" for EMS queue stats collection");
	    }
	    catch (IOException ex)
	    {
		error("creating Prometheus HTTPServer on port "+m_queueStatsPort+" "+ex.toString());
		System.exit(1);
	    }
	}
	if (m_topicStatsPort > 0)
	{
	    try
	    {
		m_topicHTTPServer = new HTTPServer(new InetSocketAddress(m_topicStatsPort), m_topicRegistry);
		info("Started Prometheus client HTTPServer on port "+m_topicStatsPort+" for EMS topic stats collection");
	    }
	    catch (IOException ex)
	    {
		error("creating Prometheus HTTPServer on port "+m_topicStatsPort+" "+ex.toString());
		System.exit(1);
	    }
	}

    }

    public void doServerLogging(String serverName, Hashtable statsValues, Date timestamp, long responseTime)
    {
	if (m_serverHTTPServer != null)
	{
	    // Add stats to the prometheous collectors
	    for ( int j = 0; j < m_serverStatsNames.size(); j++ ) {

		String n = m_serverStatsNames.get(j);
		SimpleCollector c = m_serverCollectors.get(n);
		Object val = statsValues.get(n);
		double dval = 0.0;
		if (val instanceof Integer)
		    dval = ((Integer)val).doubleValue();
		else if (val instanceof Long)
		    dval = ((Long)val).doubleValue();
		else if (val instanceof Double)
		    dval = (Double)val;
		else
		    error("Failed to convert metric type: "+val.getClass().getName()+" server: "+serverName);

		if (Arrays.asList(m_statsCounterTypes).contains(n))
		{
		    if (dval < ((Counter)c).labels(m_jobName, serverName).get())
		    {
			debug("Counter reset for metric: "+n+" server: "+serverName);
			//((Counter)c).clear(); // Clear will clear all values for all labels...
			((Counter)c).remove(m_jobName, serverName);
		    }
		    ((Counter)c).labels(m_jobName, serverName).inc(dval- ((Counter)c).labels(m_jobName, serverName).get());
		}
		else
		    ((Gauge)c).labels(m_jobName, serverName).set(dval);
	    }

	    m_respTimeGauge.labels(m_jobName, serverName).set(responseTime);
	}

	if (!m_nolog)
	{
	    super.doServerLogging(serverName, statsValues, timestamp, responseTime);
	}
    }

    public void doDestinationLogging(String serverName, String pattern, String destName, Hashtable statsValues, Date timestamp, boolean isQueue)
    {
	if ((isQueue && m_queueHTTPServer != null) || (!isQueue && m_topicHTTPServer != null))
	{
	    String destType;
	    Vector<String> statsNames;
	    if (isQueue)
	    {
		destType="Queue";
		statsNames = m_queueStatsNames; 
	    } else
	    {
		statsNames = m_topicStatsNames;
		destType="Topic";
	    }
	    // Add stats to the prometheous collectors
	    for ( int j = 0; j < statsNames.size(); j++ ) {

		String n = statsNames.get(j);
		SimpleCollector c;
		if (isQueue)
		    c = m_queueCollectors.get(n);
		else
		    c = m_topicCollectors.get(n);
		Object val = statsValues.get(n);
		double dval = 0.0;
		if (val instanceof Integer)
		    dval = ((Integer)val).doubleValue();
		else if (val instanceof Long)
		    dval = ((Long)val).doubleValue();
		else if (val instanceof Double)
		    dval = (Double)val;
		else
		    error("Failed to convert metric type: "+val.getClass().getName()+" server: "+serverName+" "+destType+": "+destName);

		if (Arrays.asList(m_statsCounterTypes).contains(n))
		{
		    if (dval < ((Counter)c).labels(m_jobName, serverName, destName).get())
		    {
			debug("Counter reset for metric: "+n+" server: "+serverName+" "+destType+": "+destName+ "(maybe dynamic or server has restarted)");
			//((Counter)c).clear(); // Clear will clear all values for all labels...
			((Counter)c).remove(m_jobName, serverName, destName);
		    }
		    ((Counter)c).labels(m_jobName, serverName, destName).inc(dval- ((Counter)c).labels(m_jobName, serverName, destName).get());
		}
		else
		    ((Gauge)c).labels(m_jobName, serverName, destName).set(dval);
	    }
	}

	if (!m_nolog)
	{
	    super.doDestinationLogging(serverName, pattern, destName, statsValues, timestamp, isQueue);
	}
    }

    public void serverDisconnected(EmsServer con, String reason)
    {
	super.serverDisconnected(con, reason);

	SimpleCollector col;
	Set<String> keys = m_serverCollectors.keySet();
	debug("Removing values for all server metrics for server "+con.m_alias);
        for(String key: keys){
	    col = m_serverCollectors.get(key);
	    col.remove(m_jobName, con.m_alias);
        }
	m_respTimeGauge.remove(m_jobName, con.m_alias);

	//TODO how to remove stale queue/topic metrics?
	// There is no way to iterate through sub labels
	// destintation metrics may also become stale for dynamic destinations when the expire

	debug("Queue/Topic metrics may be stale for server "+con.m_alias);
    }

    public static void main(String[] args)
    {
        EmsStatsPromCollector t = new EmsStatsPromCollector(args);
    }

    public int parseArg(String[] args, int i)
    {
	int inc = super.parseArg(args, i);

        if (inc < 0 && i < args.length)
        {
            if (args[i].compareTo("-nolog")==0)
            {
                m_nolog = true;
                return 0;
            }
            else
            if (args[i].compareTo("-serverStatsPort")==0)
            {
                if ((i+1) >= args.length) usage();
                try {
                    m_serverStatsPort = Integer.parseInt(args[i+1]);
                }
                catch(NumberFormatException e) {
                    error("invalid value for -serverStatsPort parameter");
                    usage();
                }
                return 1;
            }
            else
            if (args[i].compareTo("-queueStatsPort")==0)
            {
                if ((i+1) >= args.length) usage();
                try {
                    m_queueStatsPort = Integer.parseInt(args[i+1]);
                }
                catch(NumberFormatException e) {
                    error("invalid value for -queueStatsPort parameter");
                    usage();
                }
                return 1;
            }
            else
            if (args[i].compareTo("-topicStatsPort")==0)
            {
                if ((i+1) >= args.length) usage();
                try {
                    m_topicStatsPort = Integer.parseInt(args[i+1]);
                }
                catch(NumberFormatException e) {
                    error("invalid value for -topicStatsPort parameter");
                    usage();
                }
                return 1;
            }
	    else
            if (args[i].compareTo("-job")==0)
            {
                if ((i+1) >= args.length) usage();
                m_jobName = args[i+1];
                return 1;
            }
        }
	return inc;
    }
    public void usage()
    {
        usage("\nUsage: java EmsStatsPromCollector [options]", false);
        System.out.println("  -serverStatsPort  <port>       - The HTTP port to scrape for EMS server stats, default 9091. (0 disables)");
        System.out.println("  -queueStatsPort   <port>       - The HTTP port to scrape for EMS queue stats, default 9092. (0 disables)");
        System.out.println("  -topicStatsPort   <port>       - The HTTP port to scrape for EMS topic stats, default 9093. (0 disables)");
        System.out.println("  -job   <job-name>              - The Prometheus job-name, default TIB-EMS");
        System.out.println("  -nolog                         - Prevent all logging of stats to logdir, default false");
        System.exit(0);
    }
}


