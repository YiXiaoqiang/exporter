/* Copyright (c) 2017-2018 TIBCO Software Inc.
 * All rights reserved.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 * 
 * TIBCO EMS Server Statistics AWS CloudWatch Pusher
 *
 * Uses EMS Admin API to collect server info stats and push them to a AWS CloudWatch
 *
 * Compile with:
 *	- EMS client API V8.1 or greater; tibjmsadmin.jar
 *	- AWS SDK; aws-java-sdk-1.11.321.jar
 * 		https://github.com/aws/aws-sdk-java
 *
 * @author rlawrence
 * 
 */

import java.util.Hashtable;
import java.util.Date;
import java.util.Vector;

import com.tibco.tibjms.admin.*;

import com.amazonaws.services.cloudwatch.AmazonCloudWatchClient;
import com.amazonaws.services.cloudwatch.AmazonCloudWatchClientBuilder;
import com.amazonaws.services.cloudwatch.model.Dimension;
import com.amazonaws.services.cloudwatch.model.MetricDatum;
import com.amazonaws.services.cloudwatch.model.PutMetricDataRequest;
import com.amazonaws.services.cloudwatch.model.PutMetricDataResult;
import com.amazonaws.services.cloudwatch.model.StandardUnit;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;

public class EmsStatsCloudWatchPusher extends EmsStatsLogger 
{

    protected String m_accessId = null;
    protected String m_secretKey = null;
    protected String m_region = null;
    protected String m_namespace  =  "TIBCO/EMS";
    protected AmazonCloudWatchClient m_cw = null;
    protected boolean m_nolog =  false;

    // Determine the metric unit type from its name
    public StandardUnit getUnitTypeFromName(String name) {

	if (name.endsWith("Count"))
	    return StandardUnit.Count;
	else if (name.endsWith("Size") || name.endsWith("Bytes") || name.contains("msgMem"))
	    return StandardUnit.Bytes;
	else if (name.endsWith("BytesRate"))
	    return StandardUnit.BytesSecond;
	else if (name.endsWith("OperationsRate"))
	    return StandardUnit.CountSecond;
	else if (name.equals("diskReadRate") || name.equals("diskWriteRate"))
	    return StandardUnit.BytesSecond;
	else if (name.endsWith("Rate"))
	    return StandardUnit.CountSecond;
	else if (name.endsWith("Messages"))
	    return StandardUnit.Count;
	else 
	{
	    warn("could not determine CouldWatch Unit type from name: "+name);
	    return StandardUnit.None;
	}


    }
    public EmsStatsCloudWatchPusher(String[] args) {

	m_interval = 60;
        parseArgs(args);
	init();
    	run();
    }

    public void init()
    {
	super.init();

	try
	{
	    // Get the current region or use region specified
	    if (m_region == null)
	    {
		Region region = Regions.getCurrentRegion();
		if (region != null)
		    m_region = region.getName();
	    }

	    if (m_region == null)
	    {
		error("AWS region must be specified");
		usage();
	    }

	    AWSCredentialsProvider credentials = null;

	    // If credentials not supplied on command line, populate from environment
	    if (m_accessId == null || m_secretKey == null)
		credentials = new DefaultAWSCredentialsProviderChain();
	    else
		credentials = new AWSStaticCredentialsProvider(new BasicAWSCredentials(m_accessId, m_secretKey));

	    if (credentials == null )
	    {
		error("Failed to create AWS credentials");
		System.exit(1);
	    }
            AmazonCloudWatchClientBuilder builder  =  AmazonCloudWatchClientBuilder.standard().withCredentials(credentials).withRegion(m_region);

            m_cw = (AmazonCloudWatchClient) builder.build();

	    info("Pushing EMS stats to CloudWatch region: "+m_region);
	}
	catch(Exception ie)
	{
	    error("Failed to create CloudWatch client: "+ie.getMessage());
	    System.exit(1);
	}
    }

    public void doServerLogging(String serverName, Hashtable statsValues, Date timestamp, long responseTime)
    {

	if (m_cw != null)
	{
	    try
	    {
		Dimension dimension = new Dimension().withName("EMS-Server").withValue(serverName);

		// Push stats to CloudWatch
		for ( int j = 0; j < m_serverStatsNames.size(); j++ ) {

		    String n = m_serverStatsNames.get(j);
		    Object val = statsValues.get(n);
		    double dval = 0.0;
		    if (val instanceof Integer)
			dval = ((Integer)val).doubleValue();
		    else if (val instanceof Long)
			dval = ((Long)val).doubleValue();
		    else if (val instanceof Double)
			dval = (Double)val;
		    else
			error("Failed to convert mertic type: "+val.getClass().getName());

		    MetricDatum datum = new MetricDatum()
			.withMetricName(n)
			.withUnit(getUnitTypeFromName(n))
			.withValue(dval)
			.withDimensions(dimension)
			.withTimestamp(timestamp);

		    PutMetricDataRequest request = new PutMetricDataRequest()
			.withNamespace(m_namespace)
			.withMetricData(datum);

		    PutMetricDataResult response = m_cw.putMetricData(request);
		}

		// Add the response time metric
		MetricDatum datum = new MetricDatum()
		    .withMetricName("responseTime")
		    .withUnit(StandardUnit.Milliseconds)
		    .withValue((double)responseTime)
		    .withDimensions(dimension)
		    .withTimestamp(timestamp);

		PutMetricDataRequest request = new PutMetricDataRequest()
		    .withNamespace(m_namespace)
		    .withMetricData(datum);

		PutMetricDataResult response = m_cw.putMetricData(request);
	    }
	    catch(Exception ie)
	    {
		error("Failed to push server stats to CloudWatch: "+ie.getMessage());
	    }
	}

	if (!m_nolog)
	{
	    super.doServerLogging(serverName, statsValues, timestamp, responseTime);
	}
    }

    public void doDestinationLogging(String serverName, String pattern, String destName, Hashtable statsValues, Date timestamp, boolean isQueue)
    {
	if (m_cw != null)
	{
	    try
	    {
		Dimension dimension = new Dimension().withName("EMS-Server").withValue(serverName);
		String destType;
		Vector<String> statsNames;
		if (isQueue)
		{
		    destType="Queue";
		    statsNames = m_queueStatsNames; 
		} else
		{
		    statsNames = m_topicStatsNames;
		    destType="Topic";
		}
		Dimension dimension1 = new Dimension().withName(destType).withValue(destName);

		// Push stats to CloudWatch
		for ( int j = 0; j < statsNames.size(); j++ ) {

		    String n = statsNames.get(j);
		    Object val = statsValues.get(n);
		    double dval = 0.0;
		    if (val instanceof Integer)
			dval = ((Integer)val).doubleValue();
		    else if (val instanceof Long)
			dval = ((Long)val).doubleValue();
		    else if (val instanceof Double)
			dval = (Double)val;
		    else
			error("Failed to convert mertic type: "+val.getClass().getName());

		    MetricDatum datum = new MetricDatum()
			.withMetricName(n)
			.withUnit(getUnitTypeFromName(n))
			.withValue(dval)
			.withDimensions(dimension,dimension1)
			.withTimestamp(timestamp);

		    PutMetricDataRequest request = new PutMetricDataRequest()
			.withNamespace(m_namespace)
			.withMetricData(datum);

		    PutMetricDataResult response = m_cw.putMetricData(request);
		}
	    }
	    catch(Exception ie)
	    {
		error("Failed to push destination stats to CloudWatch: "+ie.getMessage());
	    }
	}

	if (!m_nolog)
	{
	    super.doDestinationLogging(serverName, pattern, destName, statsValues, timestamp, isQueue);
	}
    }
    
    public static void main(String[] args)
    {
        EmsStatsCloudWatchPusher t = new EmsStatsCloudWatchPusher(args);
    }

    public int parseArg(String[] args, int i)
    {
	int inc = super.parseArg(args, i);

        if (inc < 0 && i < args.length)
        {
            if (args[i].compareTo("-nolog")==0)
            {
                m_nolog = true;
                return 0;
            }
            else
            if (args[i].compareTo("-accessId")==0)
            {
                if ((i+1) >= args.length) usage();
                m_accessId = args[i+1];
                return 1;
            }
            else
            if (args[i].compareTo("-secretKey")==0)
            {
                if ((i+1) >= args.length) usage();
                m_secretKey = args[i+1];
                return 1;
            }
            else
            if (args[i].compareTo("-region")==0)
            {
                if ((i+1) >= args.length) usage();
                m_region = args[i+1];
                return 1;
            }
            else
            if (args[i].compareTo("-ns")==0)
            {
                if ((i+1) >= args.length) usage();
                m_namespace = args[i+1];
                return 1;
            }
        }
	return inc;
    }
    public void usage()
    {
        usage("\nUsage: java EmsStatsCloudWatchPusher [options]", false);
        System.out.println("  -accessId  <accessId>          - AWS access Id (default environment credentials)");
        System.out.println("  -secretKey <secretKey>         - AWS secret key (default environment credentials)");
        System.out.println("  -region    <region>            - AWS region (default current region)");
        System.out.println("  -ns        <namespace>         - AWS namespace (default TIBCO/EMS)");
        System.out.println("  -nolog                         - Prevent all logging of stats to logdir, default false");
        System.exit(0);
    }
}


