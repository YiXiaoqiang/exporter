TIBEMS_ROOT=$HOME/tibco/ems/8.4
AWSSDK_ROOT=./aws-java-sdk-1.11.321
AWSSDK_LIB=$AWSSDK_ROOT/lib
TIBEMS_LIB=$TIBEMS_ROOT/lib
CLASSPATH=emsStatsLogger.jar:$TIBEMS_LIB/tibjmsadmin.jar:$TIBEMS_LIB/jms-2.0.jar:$TIBEMS_LIB/tibjms.jar:$AWSSDK_LIB/aws-java-sdk-1.11.321.jar:$AWSSDK_ROOT/third-party/lib/commons-logging-1.1.3.jar:$AWSSDK_ROOT/third-party/lib/jackson-databind-2.6.7.1.jar:$AWSSDK_ROOT/third-party/lib/jackson-core-2.6.7.jar:$AWSSDK_ROOT/third-party/lib/jackson-annotations-2.6.0.jar:$AWSSDK_ROOT/third-party/lib/httpcore-4.4.9.jar:$AWSSDK_ROOT/third-party/lib/httpclient-4.5.5.jar:$AWSSDK_ROOT/third-party/lib/joda-time-2.8.1.jar

java -cp $CLASSPATH EmsStatsCloudWatchPusher -config servers.xml -interval 60 -accessId AKIAJDCSZSTJLHNEBHDA -secretKey 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 -region eu-central-1 -nolog 
