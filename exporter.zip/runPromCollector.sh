TIBEMS_ROOT=$HOME/tibco/ems/8.4
TIBEMS_LIB=$TIBEMS_ROOT/lib
CLASSPATH=emsStatsLogger.jar:$TIBEMS_LIB/tibjmsadmin.jar:$TIBEMS_LIB/jms-2.0.jar:$TIBEMS_LIB/tibjms.jar

java -cp $CLASSPATH EmsStatsPromCollector -config servers.xml -interval 60 -queueStatsPort 9092 -debug
